package apps.easyorm.simple.main;

import ib.easyorm.exception.EasyORMException;
import ib.easyorm.logging.Logger;
import ib.easyorm.logging.Logger.LogMsgType;

public class LogTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
		Logger.setLogFileName("C:\\test\\logger.log");
		Logger logger = new Logger(LogTester.class);
		logger.enableAllLogMsgTypes();//enable every log type
		logger.disbleLogMsgType(LogMsgType.MSG_LOG_ERROR);//disable error message
		logger.info("This is the first info line");
		logger.info("This is the second info line");
		logger.debug("This is the first debug line");
		logger.info("This is the third info line");
		logger.error("This is the first error line");//this will not end up in the log file
		logger.flush();//this writes to file everything that has not been written and closes the file stream
		}catch(EasyORMException e){
			
		}
	}

}
