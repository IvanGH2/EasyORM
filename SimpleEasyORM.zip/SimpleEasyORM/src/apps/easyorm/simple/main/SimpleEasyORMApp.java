package apps.easyorm.simple.main;

import ib.easyorm.db.ConnectionPool;
import ib.easyorm.db.DBSelect;
import ib.easyorm.db.DBTransaction;
import ib.easyorm.exception.EasyORMException;
import ib.easyorm.logging.Logger;

import java.util.HashMap;
import java.util.List;

import apps.easyorm.simple.db.AddressDB;
import apps.easyorm.simple.db.EmployeeByDept;
import apps.easyorm.simple.db.EmployeeDB;

public class SimpleEasyORMApp {
	static Logger logger;

	public static void main(String[] args) {

		final String jdbcDriver = "org.postgresql.Driver";
		final String jdbcURL    = "jdbc:postgresql://localhost:5432/SimpleWebTest";
		final String user       = "postgres";
		final String password   = "1111";
		EmployeeDB emp = null;
		AddressDB address=null;
		DBTransaction dbTrx=null;		
		try{
			Logger.setLogFileName("C:\\test\\TestLog.log");
			logger = new Logger(SimpleEasyORMApp.class);
			logger.enableAllLogMsgTypes();
			//-obtain a reference to the Connection pool 
			ConnectionPool connPool = ConnectionPool.getInstance(jdbcDriver, jdbcURL, user, password);
			//create a transaction object that will be used for commits/rollbacks but it also reuses connections form the pool
			dbTrx=new DBTransaction(connPool);

			//now create address and emp objects and populate them with data
			java.sql.Date sqlDate=java.sql.Date.valueOf("2015-06-26");
			System.out.println("Creating Address and Employee objects");
			printToLog("Creating Address and Employee objects",Logger.LogMsgType.MSG_LOG_INFO);
			address = new AddressDB(dbTrx);
			address.setCity("Prague");
			address.setStreetName("Wenceslas square");
			address.setStreetNumber("2");
			address.setDateAdded(sqlDate);
			address.setDateUpdated(sqlDate);

			System.out.println("Inserting record for Address");
			printToLog("Inserting record for Address",Logger.LogMsgType.MSG_LOG_INFO);
			int addId=address.insert();
			System.out.println("Record for Address inserted with id: "+addId);
			printToLog("Record for Address inserted with id: "+addId,Logger.LogMsgType.MSG_LOG_INFO);
			emp = new EmployeeDB(dbTrx);
			emp.setName("Petr");
			emp.setSurame("Henin");
			emp.setDepartment("Finances");
			emp.setYearsAtWork(12);
			emp.setAddressId(addId);//or address.getId()
			emp.setDateAdded(sqlDate);
			emp.setDateUpdated(sqlDate);

			System.out.println("Inserting record for Employee");
			printToLog("Inserting record for Employee",Logger.LogMsgType.MSG_LOG_INFO);
			int empId=emp.insert();
			System.out.println("Record for Employee inserted with id: "+empId);
			printToLog("Record for Employee inserted with id: "+empId,Logger.LogMsgType.MSG_LOG_INFO);

			System.out.println("Committing to Address/Employee tables");
			printToLog("Record for Employee inserted with id: "+empId,Logger.LogMsgType.MSG_LOG_DEBUG);
			dbTrx.commit();

			//display employee records from Employee table
			DBSelect dbSelect=new DBSelect();
			List<EmployeeDB> empList = dbSelect.getRecordsForSingleTable(EmployeeDB.class, 0, 0);

			if(empList.size()>0){
				System.out.println("\nPrinting employee records\n");
				printToLog("\nPrinting employee records\n",Logger.LogMsgType.MSG_LOG_INFO);

				for(EmployeeDB employee:empList){
					System.out.println(printEmployee(employee));
					printToLog(printEmployee(employee),Logger.LogMsgType.MSG_LOG_INFO);

				}
			}else{
				System.out.println("No employee records found");
				printToLog("\nNo employee records found\n",Logger.LogMsgType.MSG_LOG_INFO);
			}

			//display employee records from Employee table as well as Address table (this is a simple join)
			String query="select employee.*, address.* from  employee left outer join address on employee.address_id=address.id ";
			empList = dbSelect.getRecordsForCustomQuery(query, EmployeeDB.class, 0, 0);
			if(empList.size()>0){
				System.out.println("\nPrinting employee records for custom query\n");
				for(EmployeeDB employee:empList){
					System.out.println(printEmployee(employee));
					printToLog(printEmployee(employee),Logger.LogMsgType.MSG_LOG_INFO);
				}
			}else{
				System.out.println("No employee records found");
				printToLog("\nNo employee records found\n",Logger.LogMsgType.MSG_LOG_INFO);
			}
			HashMap<String,Object>hMap=new HashMap<String,Object>();
			hMap.put("firstName", "Petr");
			hMap.put("lastName", "Henin");		
			empList = dbSelect.getRecordsForParamQuery("select * from employee  where  first_name=:firstName and last_name=:lastName",hMap, EmployeeDB.class,0,0);
			if(empList.size()>0){
				System.out.println("Printing employee records for custom, parameterized query\n");
				printToLog("Printing employee records for custom, parameterized query\n",Logger.LogMsgType.MSG_LOG_DEBUG);
				for(EmployeeDB employee:empList){
					System.out.println(printEmployee(employee));
				}
				//let's update this last record so that Pierre Henry is now an employee in Human Resources
				emp = empList.get(0);//if there are more people by the name of Pierre Henry, we'll change only the first one
				System.out.println("\nUpdating employee "+emp.getName()+" "+emp.getSurname());
				printToLog("\nUpdating employee "+emp.getName()+" "+emp.getSurname(), Logger.LogMsgType.MSG_LOG_INFO);
				emp.setDepartment("Human Resources");
				emp.update();
			}else{
				System.out.println("\nNo employee records found for parameterized query");
				printToLog("\nNo employee records found for parameterized query\n", Logger.LogMsgType.MSG_LOG_INFO);
			}
			System.out.println("\nGetting a scalar value for a custom query");
			printToLog("\nNo employee records found for parameterized query\n", Logger.LogMsgType.MSG_LOG_DEBUG);
			query="select count(id) from employee";
			Long numEmployees=(Long)dbSelect.getScalarValueForCustomQuery(query, true);
			System.out.println("Number of employees: "+numEmployees);
			printToLog("\nNumber of employees: \n", Logger.LogMsgType.MSG_LOG_INFO);
			//obtaining a custom view
			query = "SELECT department, count(department) as dept_count FROM employee GROUP BY department";
			List<EmployeeByDept> empDeptList = dbSelect.getRecordsForCustomQuery(query, EmployeeByDept.class, 0, 0);

			if(empDeptList.size()>0){
				System.out.println("\nPrinting employee records for custom, parameterized query\n");
				printToLog("\nPrinting employee records for custom, parameterized query\n", Logger.LogMsgType.MSG_LOG_INFO);
				for(EmployeeByDept dept:empDeptList){
					System.out.println(printEmployeeNumberByDept(dept));
				}
			}else{
				printToLog("\nNo employee number by department records found for custom query", Logger.LogMsgType.MSG_LOG_INFO);
				System.out.println("\nNo employee number by department records found for custom query");
			}

			query=" select emp.*, cer.cert_name from employee emp, certificate cer, employee_certificate ec"+
					" where emp.id=ec.emp_id and ec.cert_id=cer.id ";

			empList = dbSelect.getRecordsForCustomQuery(query, EmployeeDB.class, 0, 0);
			if(empList.size()>0){
				System.out.println("\nPrinting employee/certificate records for custom query\n");
				printToLog("\nPrinting employee/certificate records for custom quer<\n", Logger.LogMsgType.MSG_LOG_INFO);
				for(EmployeeDB employee:empList){
					System.out.println(printEmployee(employee));
					printToLog(printEmployee(employee), Logger.LogMsgType.MSG_LOG_INFO);
				}
			}else{
				System.out.println("\nNo employee records found for custom query");
				printToLog("\nNo employee records found for custom query", Logger.LogMsgType.MSG_LOG_INFO);
			}
			//System.out.println("\nDeleting employee "+emp.getName()+" "+emp.getSurname());
			//printToLog("\nDeleting employee "+emp.getName()+" "+emp.getSurname(), Logger.LogMsgType.MSG_LOG_INFO);
			//emp.delete();

		}catch(EasyORMException e){
			System.out.println("Exception: "+e);		
			try {
				printToLog(e.getMessage(), Logger.LogMsgType.MSG_LOG_ERROR);
				if(dbTrx!=null){
					System.out.println("Rollbacking records");
					dbTrx.rollback();
				}
			} catch (EasyORMException e1) {

			}
		}
	}
	private static String printEmployee(EmployeeDB emp){

		String employee="Employee:"+" Name: "+ emp.getName();
		employee += " Surname:"+ emp.getSurname();
		employee += " Department:"+ emp.getDepartment();
		employee += " Years employed:"+ emp.getYearsAtWork();

		if(emp.getCertificateName()!=null)
			employee += " Certificate:"+ emp.getCertificateName();

		AddressDB address = emp.getAddress();
		if(address!=null&&address.getCity()!=null)
			employee += " Address:"+ address.getCity()+","+address.getStreetName()+" "+address.getStreetNumber();
		return employee;

	}
	private static String printEmployeeNumberByDept(EmployeeByDept dept){
		return "Department: "+dept.getDepartment()+" Number of employees: "+dept.getEmployeeCountByDepartment();

	}
	private static void printToLog(String logMsg, Logger.LogMsgType msgType) throws EasyORMException{

		switch(msgType){
		case MSG_LOG_DEBUG:
			logger.debug(logMsg);
			break;
		case MSG_LOG_INFO:
			logger.info(logMsg);
			break;
		case MSG_LOG_ERROR:
			logger.error(logMsg);
			break;
		}
	}
}
