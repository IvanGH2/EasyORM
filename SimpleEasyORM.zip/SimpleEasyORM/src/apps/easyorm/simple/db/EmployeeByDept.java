
package apps.easyorm.simple.db;

import ib.easyorm.db.DBObject;
import ib.easyorm.exception.EasyORMException;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;


public class EmployeeByDept extends DBObject implements Serializable {

	public EmployeeByDept(ResultSet rs) throws  EasyORMException {
		super(rs);
	}

	public EmployeeByDept(Connection conn) {
		super(conn);
	}
	public static String COLUMN_DEPARTMENT = "department";
	public static String COLUMN_EMPLOYEE_BY_DEPARTMENT = "dept_count";

	@Override
	public String getPackageName(){
		return getClass().getPackage().getName();
	}
	public java.lang.String getDepartment () {
		return (String)getValue(COLUMN_DEPARTMENT);
	}
	
	public void setDepartment (String dept) {
		setValue(COLUMN_DEPARTMENT, dept);
	}
	
	public Long getEmployeeCountByDepartment () {
		return (Long)getValue(COLUMN_EMPLOYEE_BY_DEPARTMENT);
	}
}
