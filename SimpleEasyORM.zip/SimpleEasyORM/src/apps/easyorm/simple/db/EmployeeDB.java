
package apps.easyorm.simple.db;

import ib.easyorm.annotation.AttributeInfo;
import ib.easyorm.annotation.TableInfo;
import ib.easyorm.db.DBObject;
import ib.easyorm.db.DBTransaction;
import ib.easyorm.exception.EasyORMException;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;


@TableInfo(tableName = "employee",tableIdColumnName="id")
public class EmployeeDB extends DBObject implements Serializable {

	public EmployeeDB(ResultSet rs) throws  EasyORMException {
		super(rs);
	}
	public EmployeeDB(DBTransaction dbTrx) throws  EasyORMException {
		super(dbTrx);
	}
	public EmployeeDB(Connection conn) {
		super(conn);
	}
	public EmployeeDB(){
		
	}
	//Employee table columns
	public static String COLUMN_ID = "id";
	public static String COLUMN_NAME= "first_name";
	public static String COLUMN_SURNAME = "last_name";
	public static String COLUMN_YEARS_WORK = "years_at_job";
	public static String COLUMN_DEPARTMENT = "department";
	public static String COLUMN_DATE_ADDED = "date_added"; 
	public static String COLUMN_DATE_UPDATED = "date_updated";
	public static String COLUMN_ADDRESS_ID = "address_id";
	

	
	//custom view column name - corresponds to Certificate.cert_name
	public String COLUMN_CERT_NAME = "cert_name";
	
	//holds address information but does not correspond to any column name
	public AddressDB empAddress;
	
	protected String getIdentifierColumnName() {
		return COLUMN_ID;
	}

	public AddressDB getAddress(){
		return empAddress;
	}
	@AttributeInfo(attributeType="AddressDB")
	public void setAddress(AddressDB address){
		empAddress=address;
	}

	public Integer getId () {
		return (Integer)getValue(COLUMN_ID);
	}

	public void setId (java.lang.Integer id) {
		setValue(COLUMN_ID, id);
	}
	
	public Integer getAddressId () {
		return (Integer)getValue(COLUMN_ADDRESS_ID);
	}

	public void setAddressId (java.lang.Integer id) {
		setValue(COLUMN_ADDRESS_ID, id);
	}
	
	
	public Date getDateAdded () {
		return (Date)getValue(COLUMN_DATE_ADDED);
	}

	
	public void setDateAdded (Date dateAdded) {
		setValue(COLUMN_DATE_ADDED, dateAdded);
	}
	
	public Date getDateUpdated () {
		return (Date)getValue(COLUMN_DATE_UPDATED);
	}

	
	public void setDateUpdated (Date dateUpdated) {
		setValue(COLUMN_DATE_UPDATED, dateUpdated);
	}
	public String getName () {
		return (String)getValue(COLUMN_NAME);
	}
	
	public void setName (String name) {
		setValue(COLUMN_NAME, name);
	}
	
	public String getSurname () {
		return (String)getValue(COLUMN_SURNAME);
	}
	
	public void setSurame (String surname) {
		setValue(COLUMN_SURNAME, surname);
	}
	
	public Integer getYearsAtWork () {
		return (Integer)getValue(COLUMN_YEARS_WORK);
	}
	
	public void setYearsAtWork (int years) {
		setValue(COLUMN_YEARS_WORK, years);
	}
	public String getDepartment () {
		return (String)getValue(COLUMN_DEPARTMENT);
	}
	
	public void setDepartment (String department) {
		setValue(COLUMN_DEPARTMENT, department);
	}
	
	public String getCertificateName () {
		return (String)getValue(COLUMN_CERT_NAME);
	}
	@Override
	public String getPackageName(){
		return getClass().getPackage().getName();
	}
	/*public void setCertificateName (String certName) {
		setValue(COLUMN_CERT_NAME, certName);
	}*/
	
	/*public Long getEmployeeCountByDepartment () {
		return (Long)getValue(COLUMN_EMPLOYEE_BY_DEPARTMENT);
	}*/
	
}
