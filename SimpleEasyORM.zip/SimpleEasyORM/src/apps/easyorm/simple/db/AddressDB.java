package apps.easyorm.simple.db;


import ib.easyorm.annotation.TableInfo;
import ib.easyorm.db.DBObject;
import ib.easyorm.db.DBTransaction;
import ib.easyorm.exception.EasyORMException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


@TableInfo(tableName = "address",tableIdColumnName="id")
public class AddressDB extends DBObject  {

	public AddressDB(ResultSet rs) throws EasyORMException {
		super(rs);
	}
	public AddressDB() throws  EasyORMException {
		super(AddressDB.class);
	}
	public <T>AddressDB(Object enclosingCls)  {
		super(AddressDB.class,enclosingCls);
	}
	public AddressDB(DBTransaction dbTrx) throws  EasyORMException {
		super(dbTrx);
	}
	public AddressDB(Connection conn) throws SQLException {
		super(conn, AddressDB.class);
	}//jdbcDriver,jdbcURL,user,password

	public static String COLUMN_ID = "id";
	public static String COLUMN_STREET_NAME= "street_name";
	public static String COLUMN_STREET_NUM = "street_num";
	public static String COLUMN_CITY = "city";
	public static String COLUMN_DATE_ADDED = "date_added";
	public static String COLUMN_DATE_UPDATED = "date_updated";

	@Override
	public String getPackageName(){
		return getClass().getPackage().getName();
	}

	protected String getIdentifierColumnName() {
		return COLUMN_ID;
	}
	
	public java.lang.Integer getId () {
		return (Integer)getValue(COLUMN_ID);
	}

	public void setId (java.lang.Integer id) throws EasyORMException {
		setValue(COLUMN_ID, id);
	}
	
	
	public Date getDateAdded () {
		return (Date)getValue(COLUMN_DATE_ADDED);
	}

	
	public void setDateAdded (Date dateAdded) throws EasyORMException {
		setValue(COLUMN_DATE_ADDED, dateAdded);
	}
	
	public Date getDateUpdated () {
		return (Date)getValue(COLUMN_DATE_UPDATED);
	}

	
	public void setDateUpdated (Date dateUpdated) throws EasyORMException {
		setValue(COLUMN_DATE_UPDATED, dateUpdated);
	}
	public void setDateUpdated (Long dateUpdated) throws EasyORMException {
		setValue(COLUMN_DATE_UPDATED, dateUpdated);
	}
	public java.lang.String getStreetName () {
		return (String)getValue(COLUMN_STREET_NAME);
	}
	
	public void setStreetName (String name) throws EasyORMException {
		setValue(COLUMN_STREET_NAME, name);
	}
	
	public java.lang.String getStreetNumber () {
		return (String)getValue(COLUMN_STREET_NUM);
	}
	
	public void setStreetNumber(String num) throws EasyORMException {
		setValue(COLUMN_STREET_NUM, num);
	}
	
	
	public java.lang.String getCity () {
		return (String)getValue(COLUMN_CITY);
	}
	
	public void setCity (String city)  {
		setValue(COLUMN_CITY, city);
	}
	
}