package ib.easyorm.logging;

import ib.easyorm.exception.EasyORMException;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashSet;
import java.util.Set;
/**
 * 
 * @author XXX
 *this class is used for logging to System.out (in production code we would normally log to a file)
 *it supports info , debug and error types of messages, all of which can be enabled or disabled
 */
public class Logger{
	private static String which;
	private static Set<LogMsgType> blockMsgType;
	private static Logger logger;
	private static File logFile;
	private static Writer writer;
	private static StringBuilder sb;
	private int sizeToWrite=200;
	
	private Logger(){
		
		blockMsgType = new HashSet<LogMsgType>();
		blockMsgType.add(LogMsgType.msg_log_info);

	}
	public static <T>Logger getInstance(Class<T> cls){
		which=cls.getName();
		if(logger==null)
			logger=new Logger();	
		return logger;
	}
	public static String getLogFileName(){
		return logFile.getAbsolutePath();
	}
	public static void setLogFileName(String file) throws EasyORMException{
		
		logFile = new File(file);
		try {
			
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(logFile)));
			sb=new StringBuilder();
		
		} catch (FileNotFoundException e) {
			throw new EasyORMException(e);
		}
		
	}
	public void flush() throws EasyORMException{
		if(writer!=null)
			try {
				writer.write(sb.toString());
				writer.close();
			} catch (IOException e) {
				throw new EasyORMException(e);
			}
	}
	private synchronized void writeToFile(String what, LogMsgType msgType) throws EasyORMException{
				
		
		try {
			String logType = LogMsgType.convertToString(msgType);
			sb.append(logType+" - "+which+" :"+what+" \r\n");
			if(sb.length()>=sizeToWrite){
			writer.write(sb.toString());			
			writer.flush();
			sb.delete(0, sb.length());
			sb.setLength(sizeToWrite);
			}
			}  catch (IOException e) {
				throw new EasyORMException(e);
			}finally{
				
			}
		
	}
	public void debug(String msg) throws EasyORMException{

		if(this.isLogMsgTypePresent(LogMsgType.msg_log_debug))
			writeToFile(msg,LogMsgType.msg_log_debug);
			//System.out.println(which+": DEBUG-" + msg); 
	}
	public void info(String msg) throws EasyORMException{

		if(this.isLogMsgTypePresent(LogMsgType.msg_log_info))
			writeToFile(msg,LogMsgType.msg_log_info);
			//System.out.println(which+": INFO-" + msg); 
	}
	public void error(String msg) throws EasyORMException{

		if(this.isLogMsgTypePresent(LogMsgType.msg_log_error))
			writeToFile(msg,(LogMsgType.msg_log_error));
			//System.out.println(which+": ERROR-" + msg); 
	}

	public boolean isLogMsgTypePresent(LogMsgType msgType){
		if(!blockMsgType.contains(msgType))
			return false;
		return true;
	}
	public void enableLogMsgType(LogMsgType msgType){
		blockMsgType.add(msgType);
	}
	public  void disbleLogMsgType(LogMsgType msgType){
		blockMsgType.remove(msgType);
	}
	public  void disbleAllLogMsgTypes(){
		blockMsgType.clear();
	}
	public  void enableAllLogMsgTypes(){
	
		blockMsgType.clear();	
		blockMsgType.add(LogMsgType.msg_log_debug);
		blockMsgType.add(LogMsgType.msg_log_info);
		blockMsgType.add(LogMsgType.msg_log_error);		
	}
	public static enum LogMsgType {
		
		msg_log_debug,
		msg_log_info,
		msg_log_error;
		
		private static String convertToString(LogMsgType msgType){
			
			switch(msgType){
			case msg_log_debug:
				return "DEBUG";
			case msg_log_info:
				return "INFO";
			case msg_log_error:
				return "ERROR";
			}
			return "";
		}
		
	}
}