package ib.easyorm.logging;

import ib.easyorm.exception.EasyORMException;

public class LogTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
		Logger.setLogFileName("C:\\test\\logger.log");
		Logger logger = Logger.getInstance(LogTester.class);
		logger.enableLogMsgType(Logger.LogMsgType.msg_log_debug);
		logger.info("Ovo je prva linija");
		logger.info("Ovo je druga linija");
		logger.debug("Ovo je tre�a linija");
		logger.flush();
		}catch(EasyORMException e){
			
		}
	}

}
