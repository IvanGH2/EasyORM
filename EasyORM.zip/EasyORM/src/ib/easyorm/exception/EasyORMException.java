
package ib.easyorm.exception;
public class EasyORMException extends Exception{
	
	private static final long serialVersionUID = 1000L;
	public EasyORMException(String message){
		super(message);
	}
	public EasyORMException(String message,Throwable cause){
		super(message, cause);
	}
	public EasyORMException(Throwable cause){
		super(cause);
	}
	public static final String CONNECTION_NUM_EXCEEDED = "Number of available connections has been reached ";
	public static final String QUERY_PARAMS_MISSING = "Query is missing params - check the query";
	public static final String CONSTRUCTOR_ARGS_MISSING_RESULTSET = " Class is missing a public  Constructor(ResultSet) ";
	public static final String CONSTRUCTOR_ARGS_MISSING_OBJECT = " Class is missing a  Object public  Constructor(Object)";
	public static final String TABLE_ANNOTATION_MISSING = " Class is missing a TableInfo annotation ";
	public static final String NO_UPDATE_PARAMETERS = "No update parameters have been provided";
}