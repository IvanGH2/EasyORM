package ib.easyorm.db;

import ib.easyorm.annotation.TableInfo;
import ib.easyorm.exception.EasyORMException;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

class DBMetaData{

	private List<String> columnNames=new ArrayList<String>();
	private List<String> columnTypes=new ArrayList<String>();
	private List<String> tableNames=new ArrayList<String>();
	private HashMap<String,String>columnInfo=new HashMap<String,String>();
	private DatabaseMetaData databaseMetaData;
	private Connection conn;
	private ResultSet rs;

	<T>DBMetaData(Connection conn, Class<T> target) throws  EasyORMException{
		try{
			databaseMetaData = conn.getMetaData();
		}catch(SQLException e){
			throw new EasyORMException(e);
		}

	}
	<T>DBMetaData(Connection conn) throws  EasyORMException{
		try{
			databaseMetaData = conn.getMetaData();
		}catch(SQLException e){
			throw new EasyORMException(e);
		}

	}
	<T>List<String> getColumnNames(Class<T> target) throws  EasyORMException{
		ResultSet rs=null;
		try{

			rs= databaseMetaData.getColumns(null, null, target.getAnnotation(TableInfo.class).tableName(), null);
			while(rs.next()){
				columnNames.add(rs.getString("COLUMN_NAME"));	
			}
		}catch(SQLException e){
			throw new EasyORMException(e);
		}
		finally{
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new EasyORMException(e);
				}
		}
		return columnNames;
	}
	<T> List<String> getColumnTypes(Class<T> target) throws  EasyORMException{
		ResultSet rs=null;
		try{

			rs= databaseMetaData.getColumns(null, null, target.getAnnotation(TableInfo.class).tableName(), null);
			while(rs.next()){
				columnTypes.add(rs.getString("DATA_TYPE"));	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EasyORMException(e);
		}
		finally{
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new EasyORMException(e);
				}
		}
		return columnTypes;
	}
	DatabaseMetaData getMetaData() {

		return databaseMetaData;

	}
	String getDatabaseName() throws  EasyORMException{
		try{
			return databaseMetaData.getDatabaseProductName();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EasyORMException(e);
		}
	}
	<T>HashMap<String,String> getTableColumnsInfo(Class<T> target) throws  EasyORMException{
		try{		
			rs= databaseMetaData.getColumns(null, null, target.getAnnotation(TableInfo.class).tableName(), null);
			while(rs.next()){
				columnInfo.put(rs.getString("COLUMN_NAME"), rs.getString("DATA_TYPE"));
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EasyORMException(e);
		}
		finally{
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new EasyORMException(e);
				}
		}
		return columnInfo;
	}
	List<String> getTableNames() throws  EasyORMException{
		try{

			rs= databaseMetaData.getTables(null, null, null, null);
			while(rs.next()){
				tableNames.add(rs.getString(3));
			}
		}catch (SQLException e) {
			throw new EasyORMException(e);
		}
		finally{
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					throw new EasyORMException(e);
				}
		}
		return tableNames;
	}
}