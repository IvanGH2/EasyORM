	/*This file is part of the EasyORM library.

    The EasyORM library is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The EasyORM library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with The EasyORM library.  If not, see <http://www.gnu.org/licenses/>.*/

package ib.easyorm.db;

import ib.easyorm.annotation.TableInfo;
import ib.easyorm.annotation.util.AnnotationUtil;
import ib.easyorm.exception.EasyORMException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public abstract class DBObject {

	//private static ConnectionPool connPool;
	//private DBTransaction dbTrx;
	private Connection conn;
	private List<String> paramsForUpdate=new ArrayList<String>();
	private Map<String, Object> cachedResults=new HashMap<String, Object>();
	private static String stringEncoding;

	public void setEncoding(String encoding){
		stringEncoding=encoding;
	}
	public String getEncoding(){
		return stringEncoding;
	}
	public DBObject(){

	}

	public <T>DBObject(Class<T>target) throws  EasyORMException{
		conn=ConnectionPool.getInstance().getAvailableConnection();	
	}
	protected <T>DBObject(Class<T>target,Object enclosingCls) {

		cachedResults=((DBObject)enclosingCls).cachedResults;
	}
	/*public <T>DBObject(DBTransaction dbTrx,Class<T>target) throws  EasyORMException{
		//AnnotationUtil.checkTableAnnotation(target);
		conn=dbTrx.getTransactionConnection();	
		this.dbTrx=dbTrx;
	}*/
	/*public void setTransaction(DBTransaction dbTrx){
		
		this.dbTrx=dbTrx;
	}*/
	public DBObject(ResultSet rs) throws EasyORMException{
		try{
			for (int i=1;i<=rs.getMetaData().getColumnCount();i++) {
				Object obj=rs.getObject(i);
				if(stringEncoding!=null&&obj!=null&&obj instanceof String){
					if(obj!=null&&obj instanceof String){
						try{
							cachedResults.put(rs.getMetaData().getColumnName(i), new String(((String)obj).getBytes(),stringEncoding));
						}catch(UnsupportedEncodingException e){
							throw new EasyORMException(e);
						}
					}
				}else{
					cachedResults.put(rs.getMetaData().getColumnName(i), obj);
				}
			}
		}catch (Exception e) {
			throw new EasyORMException(e);
		}
	}
	public DBObject(Connection conn){
		this.conn=conn;		
	}
	public DBObject(DBTransaction dbTrx) throws  EasyORMException{

		conn=dbTrx.getTransactionConnection();
	}
	public <T>DBObject(Connection conn,Class<T>target) {
		this.conn=conn;
	}
	public <T>Object createChildObject(Class<T> target) throws  EasyORMException{

		try{
			return target.getConstructor(Object.class).newInstance(this);
		}
		catch(Exception e){
			throw new EasyORMException(target.getName()+EasyORMException.CONSTRUCTOR_ARGS_MISSING_OBJECT);
		}
	}
	protected Object getValue(String name){		
	
		Object obj=cachedResults.get(name);
		return (obj instanceof Clob)?(String)clobToString((Clob)obj):obj;
	}

	protected void setValue(String name,Object value) {
		if(value!=null){
			if(!paramsForUpdate.contains(name)){
				paramsForUpdate.add(name);
			}
			if(stringEncoding!=null&&value instanceof String){
				try {
					cachedResults.put(name, new String(((String)value).getBytes(),stringEncoding));
				} catch (UnsupportedEncodingException e) {
					//throw new EasyORMException(e);
				}
			}else{
				cachedResults.put(name,value);
			}
		}
	}

	public int insert() throws  EasyORMException{
		AnnotationUtil.checkTableAnnotation(getClass());
		Object id=null;
		List<Object> params=new ArrayList<Object>();	
		String names="";
		String values="";
		String query="";
		if(paramsForUpdate.size()>0){
			String name= paramsForUpdate.get(0);
			names+=name;
			values+="?";
			params.add(cachedResults.get(name));
			for (int i=1;i<paramsForUpdate.size();i++) 
			{
				name= paramsForUpdate.get(i);
				names+=","+name;
				values+=","+"?";
				params.add(cachedResults.get(name));

			}
			query="insert into "+getClass().getAnnotation(TableInfo.class).tableName()+" ("+names+") values ("+values+")";
		}else{
			throw new EasyORMException(EasyORMException.NO_UPDATE_PARAMETERS);
		}
		if(query.length()>0)
		{
			id=doInsert(query, params);
			if(id instanceof Number)
				id=((Number)id).intValue();
			setValue(getClass().getAnnotation(TableInfo.class).tableIdColumnName(), id);
		}
		paramsForUpdate.clear();
		return id!=null?((Integer)id).intValue():-1;
	}
	public int update() throws  EasyORMException{
		AnnotationUtil.checkTableAnnotation(getClass());
		List<Object> params=new ArrayList<Object>();
		String query="";
		String name="";
		if(paramsForUpdate.size()>0){
			name=paramsForUpdate.get(0);
			query+=name+"=?";
			params.add(cachedResults.get(name));
			for (int i=1;i<paramsForUpdate.size();i++) 
			{
				name= paramsForUpdate.get(i);
				query+=", "+name+"=?";
				params.add(cachedResults.get(name));
			}
			query="update "+getClass().getAnnotation(TableInfo.class).tableName()+" set "+query+" where "+getClass().getAnnotation(TableInfo.class).tableIdColumnName()+"="+getValue(getClass().getAnnotation(TableInfo.class).tableIdColumnName());
		}else{
			throw new EasyORMException(EasyORMException.NO_UPDATE_PARAMETERS);
		}
		return doUpdate(query,params);
	}
	public int update(String where) throws  EasyORMException{
		AnnotationUtil.checkTableAnnotation(getClass());
		List<Object> params=new ArrayList<Object>();
		String query="";
		if(where==null||where.isEmpty())
			throw new EasyORMException(EasyORMException.NO_WHERE_CLAUSE_PARAMETERS);
		if(paramsForUpdate.size()>0){
			query+=paramsForUpdate.get(0)+"=?";
			params.add(cachedResults.get(paramsForUpdate.get(0)));
			for (int i=1;i<paramsForUpdate.size();i++) 
			{
				String name= paramsForUpdate.get(i);
				query+=", "+name+"=?";
				params.add(cachedResults.get(name));
			}
			query="UPDATE "+getClass().getAnnotation(TableInfo.class).tableName()+" SET "+query+" WHERE "+where;

		}else{
			throw new EasyORMException(EasyORMException.NO_UPDATE_PARAMETERS);
		}
		return doUpdate(query,params);
	}
	
	public int updateRange(Integer[] ids) throws  EasyORMException{
		AnnotationUtil.checkTableAnnotation(getClass());
		List<Object> params=new ArrayList<Object>();	
		String query="";
		String name="";
		if(paramsForUpdate.size()>0){
			name=paramsForUpdate.get(0);
			query+=name+"=?";
			params.add(cachedResults.get(name));
			for (int i=1;i<paramsForUpdate.size();i++) 
			{
				name= paramsForUpdate.get(i);
				query+=", "+name+"=?";
				params.add(cachedResults.get(name));
			}
			query="UPDATE "+getClass().getAnnotation(TableInfo.class).tableName()+" SET "+query+" WHERE "+getClass().getAnnotation(TableInfo.class).tableIdColumnName()+" IN ("+getIds(ids)+")";
		}else{
			throw new EasyORMException(EasyORMException.NO_UPDATE_PARAMETERS);
		}
		return doUpdate(query,params);
	}
	private String getIds(Integer [] ids){
		String idSeq="";
		idSeq+=cachedResults.get(getClass().getAnnotation(TableInfo.class).tableIdColumnName());
		for(int id:ids){
			idSeq+=",";
			idSeq+=id;
		}
		return idSeq;
	}
	public int deleteRange(Integer[] ids) throws  EasyORMException{
		AnnotationUtil.checkTableAnnotation(getClass());
		return doUpdate("delete from "+getClass().getAnnotation(TableInfo.class).tableName()+" where "+getClass().getAnnotation(TableInfo.class).tableIdColumnName()+" IN ("+getIds(ids)+")");
	}
	public int delete()  throws EasyORMException {
		AnnotationUtil.checkTableAnnotation(getClass());
		return doUpdate("delete from "+getClass().getAnnotation(TableInfo.class).tableName()+" where "+getClass().getAnnotation(TableInfo.class).tableIdColumnName()+"="+cachedResults.get(getClass().getAnnotation(TableInfo.class).tableIdColumnName()));
	}
	public int delete(String whereClause)  throws EasyORMException {
		AnnotationUtil.checkTableAnnotation(getClass());
		return doUpdate("delete from "+getClass().getAnnotation(TableInfo.class).tableName()+" where "+whereClause);
	}
	private Object doInsert(String query,List<Object> params)throws  EasyORMException{
		PreparedStatement stmt=null;
		Object id=null;
		try{		
			stmt=conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
			int i=1;
			for (Object param : params) {	
				stmt.setObject(i++, param);
			}
			stmt.execute();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()) 
				id = rs.getObject(1);
			if(rs!=null)rs.close();
			if(stmt!=null)stmt.close();

		}catch(SQLException e){
			throw new EasyORMException(e);
		}
		return id;
	}
	public int doUpdate(String query)throws  EasyORMException
	{
		int updateCount=0;
		Statement stmt=null;
		try
		{	
			stmt=conn.createStatement();
			updateCount=stmt.executeUpdate(query);
			stmt.close();
			stmt=null;
		}
		catch(SQLException e){
			throw new EasyORMException(e);
		}
		return updateCount;
	}
	public int doUpdate(String query,List<Object> params)throws  EasyORMException
	{
		int updateCount=0;
		PreparedStatement stmt=null;
		try
		{
			if(conn==null)
				conn=ConnectionPool.getInstance().getAvailableConnection();
			stmt=conn.prepareStatement(query);
			int i=1;
			for (Object param : params) {	
				stmt.setObject(i++, param);
			}
			updateCount=stmt.executeUpdate();

			stmt.execute();
			stmt.close();
			stmt=null;
		}
		catch(SQLException e){
			throw new EasyORMException(e);
		}
		return updateCount;
	}
	
	//protected abstract boolean processChildObjects();
	protected abstract String getPackageName();
	
	private String clobToString(Clob data) /*throws EasyORMException*/ {
	    StringBuilder sb = new StringBuilder();
	    try {
	        Reader reader = data.getCharacterStream();
	        BufferedReader br = new BufferedReader(reader);

	        String line;
	        while(null != (line = br.readLine())) {
	            sb.append(line);
	        }
	        br.close();
	    } catch (SQLException e) {
	    	//throw new EasyORMException(e);
	    } catch (IOException e) {
	    	//throw new EasyORMException(e);
	    }
	    return sb.toString();
	}
	
}
