package ib.easyorm.db;

import ib.easyorm.annotation.AttributeInfo;
import ib.easyorm.annotation.TableInfo;
import ib.easyorm.annotation.util.AnnotationUtil;
import ib.easyorm.exception.EasyORMException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DBSelect{
	
	private Connection conn;
	private DBTransaction dbTrx;
	private String jdbcDriver;
	private String jdbcURL;
	private String user;
	private String password;
	private HashMap<String, Object> whereParams;
	private DBMetaData dbMetaData;
	private List<String> columnNames = new ArrayList<String>();
	private List<String> columnTypes = new ArrayList<String>();
	private HashMap<String,String> columnInfo;
	private static String dbType;
	private boolean checkTypes;
	private int recNum=10;
	private String getProduct() throws EasyORMException{
		try {
			return conn.getMetaData().getDatabaseProductName();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EasyORMException(e);
		}	
	}
	public DBSelect(DBTransaction dbTrx, String jdbcDriver, String jdbcURL, String user, String password) throws  EasyORMException{
		setConnectionParameters(jdbcDriver, jdbcURL, user, password);
		this.conn=ConnectionPool.getInstance(jdbcDriver, jdbcURL, user, password).getAvailableConnection();		
		dbTrx.setTrxConnection(conn);
		this.dbTrx=dbTrx;
		
	}
	public DBSelect(String jdbcDriver, String jdbcURL, String user, String password) throws  EasyORMException{
		setConnectionParameters(jdbcDriver, jdbcURL, user, password);
		this.conn=ConnectionPool.getInstance(jdbcDriver, jdbcURL, user, password).getAvailableConnection();
		dbType=getProduct();
		

	}
	public <T>DBSelect(String jdbcDriver, String jdbcURL, String user, String password, Class<T> target) throws  EasyORMException{
		setConnectionParameters(jdbcDriver, jdbcURL, user, password);
		this.conn=ConnectionPool.getInstance(jdbcDriver, jdbcURL, user, password).getAvailableConnection();
		dbMetaData=new DBMetaData(conn,target);
		dbType=getProduct();	
		columnInfo=dbMetaData.getTableColumnsInfo(target);
		checkTypes=true;

	}
	public <T>List<String> getTableColumnNames(Class<T>target) throws EasyORMException{
		return dbMetaData.getColumnNames(target);
	}
	public <T>List<String> getTableColumnTypes(Class<T>target) throws  EasyORMException{
		return dbMetaData.getColumnTypes(target);
	}
	public <T>HashMap<String,String> getTableColumnInfo(Class<T>target) throws  EasyORMException{
		return dbMetaData.getTableColumnsInfo(target);
	}
	public DBSelect(Connection conn) throws SQLException{
		this.conn=conn;
		dbType=conn.getMetaData().getDatabaseProductName();
	}
	public <T>DBSelect(Connection conn, Class<T> target) throws  EasyORMException{
		this.conn=conn;
		dbMetaData=new DBMetaData(conn);

		dbType=getProduct();

		columnNames=dbMetaData.getColumnNames(target);	
		columnTypes=dbMetaData.getColumnTypes(target);
	}
	public <T>DBSelect( Class<T> target) throws  EasyORMException, SQLException{
		conn=ConnectionPool.getInstance().getAvailableConnection();
		dbType=conn.getMetaData().getDatabaseProductName();	
	}
	public DBSelect( ) throws EasyORMException{
		conn=ConnectionPool.getInstance().getAvailableConnection();
		dbType=getProduct();	
	}
	public  void setConnectionParameters(String jdbcDriver, String jdbcURL, String user, String password){
		this.jdbcDriver=jdbcDriver;
		this.jdbcURL=jdbcURL;
		this.user=user;
		this.password=password;
	}

	private String generateDbSpecificClause(int countRecord, int startRecord){
		String specificSql="";
		if("PostgreSQL".equals(dbType)){
		 specificSql=" LIMIT "+ countRecord+" OFFSET "+startRecord;
		}else if("Oracle".equals(dbType)){
			
		}else if("Microsoft SQL Server".equals(dbType)){
			//OFFSET 10 ROWS FETCH NEXT 10 ROWS ONLY
		}else if("MySQL".equals(dbType)){
			specificSql=" LIMIT "+ countRecord+","+startRecord;
		}else if("DB2".equals(dbType.substring(0, 3))){
			
		}
		return specificSql;
	}
	

	public void setRecordNumber(int recNum){
		this.recNum=recNum;
	}
	public int getRecordNumber(){
		return recNum;
	}

	public <T> List<T> getRecordsForSingleTable( Class<T> target, int startRecord, int countRecord ) throws EasyORMException {
		T obj=null;
		ResultSet rs=null;
		PreparedStatement stmt=null;
		AnnotationUtil.checkTableAnnotation(target);
		List<T> objList = new ArrayList<T>();
		countRecord = (countRecord<=0)?recNum:countRecord;
		startRecord = (startRecord<0)?0:startRecord;
		
		String query="SELECT * FROM "+target.getAnnotation(TableInfo.class).tableName()+" ORDER BY 1 "+ generateDbSpecificClause(countRecord, startRecord);
		try{
		stmt=conn.prepareStatement(query);
		rs = stmt.executeQuery();
		
		while(rs.next()){
			obj=target.getConstructor(ResultSet.class).newInstance(rs);
			objList.add(obj);
		}
		}catch(Exception e){
			throw new EasyORMException(e);
		} finally{
			closeResources(rs,stmt);
		}
		return objList;
	}
	public <T> List<T> getRecordsFromCustomQuery( String query, Class<T> target, int startRecord, int countRecord ) throws EasyORMException {
		T obj=null;
		ResultSet rs=null;
		PreparedStatement stmt=null;
		List<T> objList = new ArrayList<T>();
		countRecord = (countRecord<=0)?recNum:countRecord;
		startRecord = (startRecord<0)?0:startRecord;
		try{
		stmt=conn.prepareStatement(query+ generateDbSpecificClause(countRecord, startRecord));
		stmt=conn.prepareStatement(query);
		rs = stmt.executeQuery();
		
		while(rs.next()){
			obj=target.getConstructor(ResultSet.class).newInstance(rs);
			setChildObjects(target,obj);
			objList.add(obj);
		}
		}catch(Exception e){
			throw new EasyORMException(e);
		}finally{
			closeResources(rs,stmt);
		}
		return objList;
	}
	private <T>void setChildObjects(Class<T> parent,Object obj) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, SecurityException, InvocationTargetException, NoSuchMethodException{
		Method[] methods=parent.getDeclaredMethods();
		for(Method m : methods){
			if(m.isAnnotationPresent(AttributeInfo.class)){
				Class<? extends DBObject> childCls=(Class<? extends DBObject>) Class.forName(m.getAnnotation(AttributeInfo.class).attributeType());
				m.invoke(obj,childCls.getConstructor(Object.class).newInstance(obj));				
			}
		}
	
	}
	public <T> List<T> getRecordsFromParamQuery( String query, HashMap<String,Object>paramValues, Class<T> target, int startRecord, int countRecord ) throws EasyORMException {
		T obj=null;
		ResultSet rs=null;
		PreparedStatement stmt=null;
		List<T> objList = new ArrayList<T>();
		countRecord = (countRecord<=0)?recNum:countRecord;
		startRecord = (startRecord<0)?0:startRecord;
		List<String> queryParams=this.parseQueryForParams(query);
		if(queryParams.size()==0){
			return null;
		}
		query=this.replaceQueryParams(query);
		try{
		stmt=conn.prepareStatement(query+ generateDbSpecificClause(countRecord, startRecord));
		for(int i=1; i<=queryParams.size();i++){
			stmt.setObject(i, paramValues.get(queryParams.get(i-1)));
			/*if(checkTypes){
				//if(obj.getClass().getd == java.sql.Types.BOOLEAN);
				int t=convertType("date_added");
				switch(t){
				case java.sql.Types.DATE:
					stmt.setDate(i, java.sql.Date.valueOf((String)paramValues.get(queryParams.get(i-1))));
					break;
				case java.sql.Types.TIMESTAMP:
					stmt.setTimestamp(i, java.sql.Timestamp.valueOf((String)paramValues.get(queryParams.get(i-1))));

					break;
				default:
					stmt.setObject(i, paramValues.get(queryParams.get(i-1)));
				}

			}*/
		
		}
		rs = stmt.executeQuery();
		
		while(rs.next()){
			obj=target.getConstructor(ResultSet.class).newInstance(rs);
			objList.add(obj);
		}
		}catch(NoSuchMethodException e){
			throw new EasyORMException(target.getName()+EasyORMException.CONSTRUCTOR_ARGS_MISSING_RESULTSET);
		}catch(Exception e){
			//logiraj i baci iznimku
			throw new EasyORMException(e);
		}finally{
			closeResources(rs,stmt);
		}
		return objList;
	}

	private void closeResources(ResultSet rs, PreparedStatement stmt) throws EasyORMException {
		if(rs!=null)
			try {
				rs.close();
			} catch (Exception e) {
				throw new EasyORMException(e);
			}
		if(stmt!=null)
			try {
				stmt.close();
			} catch (Exception e) {
				throw new EasyORMException(e);
			}
	}
	private List<String> parseQueryForParams(String query) throws EasyORMException{
		 
		List<String> paramsList = new ArrayList<String>();
	    Pattern p=Pattern.compile("(:\\w+)");
	    Matcher m=p.matcher(query);
	    int i=0;
	    while(m.find()){
	    	paramsList.add(m.group(i++).substring(1));
	    }
	   if(paramsList.size()==0) 
		   throw new EasyORMException(EasyORMException.QUERY_PARAMS_MISSING);
	   return paramsList;
	}
	private String replaceQueryParams(String query){
		 
		String newQuery=query;
		List<String> paramsList = new ArrayList<String>();
	    Pattern p=Pattern.compile("(:\\w+)");
	    Matcher m=p.matcher(query);
	    int i=0;
	    while(m.find()){
	    	newQuery=newQuery.replaceFirst(m.group(i++), "?");
	    }
	   return newQuery;
	}
	private int convertType(String column){
		int converted=java.sql.Types.OTHER;
		int type=Integer.parseInt(columnInfo.get(column));
		if(java.sql.Types.DATE==type)
			converted=java.sql.Types.DATE;
		else if(java.sql.Types.TIMESTAMP==type)
			converted=java.sql.Types.TIMESTAMP;
		return converted;
	}
}