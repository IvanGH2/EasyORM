package ib.easyorm.db;

public class ConnectionProp{
	private  String jdbcDriver;
	private  String jdbcURL;
	private  String user;
	private  String password;
	private	 String dbDataSource;
	
	public String getJdbcDriver(){
		return jdbcDriver;
	}
	public void setJdbcDriver(String jdbcDriver){
		this.jdbcDriver=jdbcDriver;
	}
	public String getDbURL(){
		return jdbcURL;
	}
	public void setDbURL(String jdbcURL){
		this.jdbcURL=jdbcURL;
	}
	public String getUsername(){
		return user;
	}
	public void setUsername(String username){
		this.user=username;
	}
	public String getPassword(){
		return password;
	}
	public void setPassword(String password){
		this.password=password;
	}
	public String getDataSource(){
		return this.dbDataSource;
	}
	public void setDataSource(String dataSrc){
		this.dbDataSource=dataSrc;
	}
	}