package ib.easyorm.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE) 
public @interface TableInfo{
	public String tableName();//table or view name
	public String tableIdColumnName() ;//this is usually a primary key column
}


 

