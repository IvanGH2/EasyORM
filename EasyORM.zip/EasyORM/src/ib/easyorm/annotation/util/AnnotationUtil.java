package ib.easyorm.annotation.util;

import ib.easyorm.annotation.TableInfo;
import ib.easyorm.exception.EasyORMException;


public class AnnotationUtil{

	public static  <T>void checkTableAnnotation(Class<T> target) throws EasyORMException{
		if(!target.isAnnotationPresent(TableInfo.class)){
			throw new EasyORMException(EasyORMException.TABLE_ANNOTATION_MISSING);
		}
	}
}